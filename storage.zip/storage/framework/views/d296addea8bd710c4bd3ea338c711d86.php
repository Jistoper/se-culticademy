<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl-auto py-6 sm:px-6 lg:px-8 bg-gray-100 items-center">
        <div class="sm:container sm:mx-auto px-6 bg-culti-green-4 rounded">
            <div class="px-4 py-6 sm:px-0">
                <div class="flex space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-message-2 w-9 h-9 md:w-9 md:h-9"
                        width="20" height="20" viewBox="0 0 24 24" stroke-width="1.25" stroke="white" fill="none"
                        stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M12 20l-3 -3h-2a3 3 0 0 1 -3 -3v-6a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-2l-3 3">
                        </path>
                        <line x1="8" y1="9" x2="16" y2="9"></line>
                        <line x1="8" y1="13" x2="14" y2="13"></line>
                    </svg>
                    <h2 class="text-2xl font-semibold text-white mb-4">Create New Topic</h2>
                </div>
                <form action="<?php echo e(route('forum.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-1 p-2">
                        <h3 for="forum_title" class="block text-gray-200 mb-1">Title</h3>
                        <input type="text" name="forum_title" id="forum_title" class="p-1 form-input rounded-md shadow-sm border border-gray-300 <?php $__errorArgs = ['forum_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('forum_title')); ?>" required autofocus>
                        <?php $__errorArgs = ['forum_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4 p-2">
                        <label for="forum_desc" class="block text-gray-200 mb-1">Description</label>
                        <textarea name="forum_desc" id="forum_desc" class="p-1 form-textarea rounded-md shadow-sm w-full border border-gray-300 <?php $__errorArgs = ['forum_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="5" required><?php echo e(old('forum_desc')); ?></textarea>
                        <?php $__errorArgs = ['forum_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex items-center justify-end">
                        <button type="submit" class="bg-slate-800 hover:bg-slate-700 text-white font-semibold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            Create
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', ['title' => 'Forum'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/forum/create.blade.php ENDPATH**/ ?>