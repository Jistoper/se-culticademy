<?php $__env->startSection('content'); ?>
    <div class="w-full p-2 md:p-16 bg-gray-100">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div class="col-span-12 lg:col-span-8">
                    <?php if (isset($component)) { $__componentOriginal5420e85a2d015498fabc5c0693edbf80 = $component; } ?>
<?php $component = App\View\Components\Landing\CartTable::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.cart-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\CartTable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['carts' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($carts),'total' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($total)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5420e85a2d015498fabc5c0693edbf80)): ?>
<?php $component = $__componentOriginal5420e85a2d015498fabc5c0693edbf80; ?>
<?php unset($__componentOriginal5420e85a2d015498fabc5c0693edbf80); ?>
<?php endif; ?>
                </div>
                <div class="col-span-12 lg:col-span-4">
                    <?php if (isset($component)) { $__componentOriginalcb5131789474928af340d9748d735e3f = $component; } ?>
<?php $component = App\View\Components\Landing\CartForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.cart-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\CartForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'total' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($total)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb5131789474928af340d9748d735e3f)): ?>
<?php $component = $__componentOriginalcb5131789474928af340d9748d735e3f; ?>
<?php unset($__componentOriginalcb5131789474928af340d9748d735e3f); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.app', ['title' => 'Cart'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/landing/cart/index.blade.php ENDPATH**/ ?>