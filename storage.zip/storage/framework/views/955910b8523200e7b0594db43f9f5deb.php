<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> Culticademy</strong>
</footer>
<?php /**PATH C:\Users\62831\course\resources\views/layouts/backend/partials/footer.blade.php ENDPATH**/ ?>