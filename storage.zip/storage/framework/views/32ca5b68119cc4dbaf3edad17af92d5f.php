<div class="card card-dark">
    <div class="card-header">
        <h3 class="card-title"><?php echo e($title); ?></h3>
    </div>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
    <div class="card-footer">
        <a href="<?php echo e($url); ?>" class="btn btn-danger">
            <i class="fas fa-arrow-left"></i> Go Back
        </a>
        <button type="submit" class="btn btn-success">
            <i class="fas fa-check mr-1"></i> <?php echo e($titleBtn); ?>

        </button>
    </div>
</div><?php /**PATH C:\Users\62831\course\resources\views/components/card-form.blade.php ENDPATH**/ ?>