<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'MY TRANSACTION'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Invoice</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($transactions->firstItem() + $i); ?></td>
                                <td><?php echo e($transaction->invoice); ?></td>
                                <td><?php echo e($transaction->user->email); ?></td>
                                <td>
                                    <sup>Rp</sup> <?php echo e(moneyFormat($transaction->grand_total)); ?>

                                </td>
                                <td>
                                    <?php if($transaction->status == 'pending'): ?>
                                        <span class="badge badge-danger"><?php echo e($transaction->status); ?></span>
                                    <?php elseif($transaction->status == 'success'): ?>
                                        <span class="badge badge-success"><?php echo e($transaction->status); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-warning"><?php echo e($transaction->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($transaction->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('member.transaction.show', $transaction->id)); ?>"
                                        class="btn btn-primary btn-sm">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
            <div class="d-flex justify-content-end"><?php echo e($transactions->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', ['title' => 'Transaction'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/member/transaction/index.blade.php ENDPATH**/ ?>