<?php $__env->startSection('content'); ?>
    <!-- hero section -->
    <?php if (isset($component)) { $__componentOriginal6260a6b47e639c5c13135ddb2c41049d = $component; } ?>
<?php $component = App\View\Components\Landing\HeroSection::resolve(['title' => 'Forum','subtitle' => 'Kumpulan Comment dari para member disini','details' => 'Forum ini menyediakan ruang diskusi yang memungkinkan peserta kursus untuk bertanya, menjawab, dan berbagi pengalaman mereka seputar pertanian.','cardtitle' => 'Topic'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\HeroSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($forums)]); ?>
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-message-2 w-10 h-10 md:w-20 md:h-20"
            width="24" height="24" viewBox="0 0 24 24" stroke-width="1.25" stroke="white" fill="none"
            stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <path d="M12 20l-3 -3h-2a3 3 0 0 1 -3 -3v-6a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-2l-3 3">
            </path>
            <line x1="8" y1="9" x2="16" y2="9"></line>
            <line x1="8" y1="13" x2="14" y2="13"></line>
        </svg>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6260a6b47e639c5c13135ddb2c41049d)): ?>
<?php $component = $__componentOriginal6260a6b47e639c5c13135ddb2c41049d; ?>
<?php unset($__componentOriginal6260a6b47e639c5c13135ddb2c41049d); ?>
<?php endif; ?>
    <!-- search section -->
    <?php if (isset($component)) { $__componentOriginalec34e7763d23a96ad0a81b02e840c3b3 = $component; } ?>
<?php $component = App\View\Components\Landing\SearchSection::resolve(['url' => route('forum.index')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.search-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\SearchSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['search' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($search)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec34e7763d23a96ad0a81b02e840c3b3)): ?>
<?php $component = $__componentOriginalec34e7763d23a96ad0a81b02e840c3b3; ?>
<?php unset($__componentOriginalec34e7763d23a96ad0a81b02e840c3b3); ?>
<?php endif; ?>
    <!-- Forum section -->
    <div class="w-full bg-gray-100 p-3 border border-line border-gray-100">
        <div class="container mx-auto">
            <div class="flex flex-row overflow-x-auto md:grid md:grid-cols-3 gap-4 items-start">
                <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="min-w-full bg-slate-800 rounded-lg border border-slate-800">
                        <div class="flex justify-between p-4">
                            <div class="flex space-x-2">
                                <img width="26" height="26" src="https://img.icons8.com/sf-regular/48/FFFFFF/chat.png" alt="chat"/>
                                <a href="<?php echo e(route('forum.show', $forum->id)); ?>" class="font-semibold text-white hover:underline">
                                    <?php echo e($forum->forum_title); ?>

                                </a>
                            </div>
                            <div class="flex items-center space-x-1 text-white text-sm">
                                <img src="<?php echo e($forum->user->avatar); ?>" alt=""
                                    class="object-cover w-6 h-6 rounded-full border">
                                <span>
                                    <?php echo e($forum->user->name); ?>

                                </span>
                            </div>
                        </div>
                        <div class="p-4 space-y-2 text-sm rounded-b-lg bg-white text-gray-600 border-t border-line border-slate-800">
                            <p class="text-justify">
                                <?php echo e($forum->forum_desc); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <section class="w-full">
                <div class="flex flex-col items-center justify-center p-4 space-y-8 md:p-10 md:px-24 xl:px-48">
                    <a href="<?php echo e(route('forum.create')); ?>"
                        class="px-4 py-2 rounded-lg bg-white text-gray-800 text-base flex items-center gap-2 hover:scale-105 hover:duration-200 border-2 border-gray-900">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20">
                            <g>
                                <path fill="none" d="M0 0h24v24H0z"/>
                                <path d="M6.455 19L2 22.5V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H6.455zM11 10H8v2h3v3h2v-3h3v-2h-3V7h-2v3z"/>
                            </g>
                        </svg>
                        Add Topic
                    </a>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', ['title' => 'Forum'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/forum/index.blade.php ENDPATH**/ ?>