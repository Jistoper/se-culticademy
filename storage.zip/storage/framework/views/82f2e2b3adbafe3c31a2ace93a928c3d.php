<a href="<?php echo e($url); ?>" class="btn btn-dark mb-3">
    <i class="fas fa-plus-circle mr-1"></i>
    <?php echo e($title); ?>

</a><?php /**PATH C:\Users\62831\course\resources\views/components/button-create.blade.php ENDPATH**/ ?>