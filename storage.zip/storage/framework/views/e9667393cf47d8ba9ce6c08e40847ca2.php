<div class="card card-dark">
    <div class="card-header">
        <h1 class="card-title"><?php echo e($title); ?></h1>
    </div>
    <div class="card-body p-0">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH C:\Users\62831\course\resources\views/components/card.blade.php ENDPATH**/ ?>