<a href="<?php echo e($url); ?>" class="btn btn-info btn-sm">
    <i class="fas fa-edit mr-1"></i>
    Edit
</a><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/components/button-edit.blade.php ENDPATH**/ ?>