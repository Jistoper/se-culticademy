<a href="#" onclick="deleteData(<?php echo e($id); ?>)" class="btn btn-danger btn-sm">
    <i class="fas fa-trash"></i>
    Delete
</a>
<form id="delete-form-<?php echo e($id); ?>" action="<?php echo e($url); ?>" method="POST" style="display:none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/components/button-delete.blade.php ENDPATH**/ ?>