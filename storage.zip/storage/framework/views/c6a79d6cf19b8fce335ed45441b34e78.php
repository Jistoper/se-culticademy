<a href="<?php echo e($url); ?>" class="btn btn-dark mb-3">
    <i class="fas fa-plus-circle mr-1"></i>
    <?php echo e($title); ?>

</a><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/components/button-create.blade.php ENDPATH**/ ?>