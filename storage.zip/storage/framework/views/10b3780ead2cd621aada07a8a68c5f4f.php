<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'DETAIL TRANSACTION'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td width="30%">No.Invoice</td>
                            <td>
                                <?php echo e($transaction->invoice); ?>

                            </td>
                        </tr>
                        <tr>
                            <td width="30%">Nama Lengkap</td>
                            <td>
                                <?php echo e($transaction->user->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <td width="30%">Email</td>
                            <td>
                                <?php echo e($transaction->user->email); ?>

                            </td>
                        </tr>
                        <tr>
                            <td width="30%">Status</td>
                            <td>
                                <?php if($transaction->status == 'success'): ?>
                                    <button class="btn btn-primary btn-sm" disabled>Pembayaran Telah Diverifikasi
                                        Sistem</button>
                                <?php elseif($transaction->status == 'pending'): ?>
                                    <button id="pay-button" class="btn btn-info btn-sm">
                                        Lanjutkan Pembayaran
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-danger btn-sm" disabled>
                                        pembayaran untuk pesanan Anda sudah kedaluwarsa
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td width="30%">Tanggal Pembelian</td>
                            <td>
                                <?php echo e($transaction->created_at->format('d M Y H:i:s')); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
        </div>
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'DETAIL ITEMS'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>COURSE</th>
                            <th class="text-right">PRICE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($order->course->name); ?>

                                </td>
                                <td class="text-right">
                                    <sup>Rp</sup> <?php echo e(moneyFormat($order->price)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="font-weight-bold">GRAND TOTAL</td>
                            <td class="text-right text-success font-weight-bold">
                                <sup>Rp</sup> <?php echo e(moneyFormat($grandTotal)); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="<?php echo e(config('services.midtrans.serverKey')); ?>"></script>
    <script type="text/javascript">
        var payButton = document.getElementById('pay-button');
        payButton.addEventListener('click', function() {
            window.snap.pay('<?php echo e($snapToken); ?>');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', ['title' => 'Transaction Detail'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/admin/transaction/show.blade.php ENDPATH**/ ?>