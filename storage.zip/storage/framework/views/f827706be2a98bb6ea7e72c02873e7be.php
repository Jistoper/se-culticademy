<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal-default<?php echo e($id); ?>">
    <i class="fas fa-edit"></i> Edit
</button><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/components/button-modal.blade.php ENDPATH**/ ?>