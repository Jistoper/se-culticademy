<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginala760563fb0088d8be145118a6d3e1bdc = $component; } ?>
<?php $component = App\View\Components\ButtonCreate::resolve(['title' => 'ADD NEW SHOWCASE','url' => route('member.showcase.create')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ButtonCreate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala760563fb0088d8be145118a6d3e1bdc)): ?>
<?php $component = $__componentOriginala760563fb0088d8be145118a6d3e1bdc; ?>
<?php unset($__componentOriginala760563fb0088d8be145118a6d3e1bdc); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'MY SHOWCASE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Project Name</th>
                            <th>Cover</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $showcases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $showcase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($showcases->firstItem() + $i); ?></td>
                                <td><?php echo e($showcase->title); ?></td>
                                <td>
                                    <img src="<?php echo e($showcase->cover); ?>" class="img-fluid" width="20">
                                </td>
                                <td><?php echo e($showcase->description); ?></td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginal8548807d29f3edf3dae16d2f4f6e7ec4 = $component; } ?>
<?php $component = App\View\Components\ButtonEdit::resolve(['url' => route('member.showcase.edit', $showcase->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ButtonEdit::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8548807d29f3edf3dae16d2f4f6e7ec4)): ?>
<?php $component = $__componentOriginal8548807d29f3edf3dae16d2f4f6e7ec4; ?>
<?php unset($__componentOriginal8548807d29f3edf3dae16d2f4f6e7ec4); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal823a59f4bd306f811c893871da93a5dc = $component; } ?>
<?php $component = App\View\Components\ButtonDelete::resolve(['id' => $showcase->id,'url' => route('member.showcase.destroy', $showcase->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ButtonDelete::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal823a59f4bd306f811c893871da93a5dc)): ?>
<?php $component = $__componentOriginal823a59f4bd306f811c893871da93a5dc; ?>
<?php unset($__componentOriginal823a59f4bd306f811c893871da93a5dc); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
            <div class="d-flex justify-content-end">
                <?php echo e($showcases->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', ['title' => 'Showcase'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/member/showcase/index.blade.php ENDPATH**/ ?>