<div class="modal fade" id="modal-default<?php echo e($id); ?>">
    <div class="modal-dialog">
        <form action="<?php echo e($url); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e($title); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e($slot); ?>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button class="btn btn-success" type="submit">
                        <i class="fas fa-check mr-1"></i> <?php echo e($titleBtn); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\Users\62831\course\resources\views/components/modal.blade.php ENDPATH**/ ?>