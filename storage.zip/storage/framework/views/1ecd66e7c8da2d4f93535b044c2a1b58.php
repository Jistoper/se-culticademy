<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['data']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['data']); ?>
<?php foreach (array_filter((['data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full bg-culti-green-4 p-5 md:p-20">
    <div class="container mx-auto">
        <div class="grid grid-cols-1 md:grid-cols-3 items-center gap-4 md:gap-20">
            <div class="md:col-span-2">
                <h1 class="text-3xl font-semibold lg:text-5xl text-white text-center md:text-start flex items-center">
                    <?php echo e($slot); ?>

                    <?php echo e($title); ?>

                </h1>
                <p class="mt-1 text-sm leading-relaxed md:text-xl md:text-start text-gray-200">
                    <?php echo e($subtitle); ?>

                </p>
                <p class="py-2 leading-relaxed text-xs text-justify md:text-sm md:text-start text-gray-300 max-w-4xl">
                    <?php echo e($details); ?>

                </p>
            </div>
            <div
                class="hidden md:flex md:text-center md:justify-center md:items-center md:row-auto mx-auto sm:mx-0 md:col-span-1">
                <div
                    class="border p-2 rounded-3xl border-gray-900 h-96 w-80 flex flex-col justify-center bg-gray-100 shadow-lg shadow-slate-900">
                    <div class="flex flex-col gap-2">
                        <span class="text-8xl text-culti-green-3 font-semibold"><?php echo e($data->count()); ?></span>
                        <span class="text-6xl text-culti-green-3 font-semibold"><?php echo e($cardtitle); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\62831\course\resources\views/components/landing/hero-section.blade.php ENDPATH**/ ?>