<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-dark">
                <div class="card-header">
                    <h1 class="card-title">
                        MY COURSE
                    </h1>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('member.mycourse')); ?>" method="GET" class="mb-3 mt-3">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search by course title..."
                                value="<?php echo e(request()->search); ?>" name="search">
                            <span class="input-group-append">
                                <button type="button" class="btn btn-info">
                                    <i class="fas fa-search"></i> Search
                                </button>
                            </span>
                        </div>
                    </form>
                    <hr>
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <img src="<?php echo e($data->course->image); ?>" class="mr-3 shadow-custom w-100">
                            </div>

                            <div class="col-md-9 mb-3 text-dark">
                                <h5 class="mt-2"><?php echo e($data->course->name); ?></h5>
                                <!--mobile -->
                                
                                <div class="progress">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="<?php echo e($data->course->percentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($data->course->percentage); ?>%"><?php echo e($data->course->percentage); ?>%</div>
                                </div>
                                
                                <div class="d-block d-md-none d-lg-none mt-3">
                                    <a href="<?php echo e(route('course.show', $data->course->slug)); ?>"
                                        class="btn shadow btn-dark btn-md mb-2 w-100">
                                        <i class="fas fa-play mr-1"></i>
                                        Lanjutkan Belajar
                                    </a>
                                    <button type="button" class="btn btn-primary btn-md mb-2 w-100" data-toggle="modal"
                                        data-target="#modal-default<?php echo e($data->course->id); ?>">
                                        <i class="fas fa-comments mr-1"></i> Review Course
                                    </button>
                                    <div class="modal fade" id="modal-default<?php echo e($data->course->id); ?>">
                                        <div class="modal-dialog">
                                            <form action="<?php echo e(route('member.review', $data->course->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Review Course</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php if (isset($component)) { $__componentOriginalbf566fc26595b9cc6779e170beef8a5a = $component; } ?>
<?php $component = App\View\Components\Select::resolve(['name' => 'rating','title' => 'Rating'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                            <option value="1">1 </option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $component = $__componentOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php $component = App\View\Components\Textarea::resolve(['title' => 'Review','name' => 'review','value' => ''.e(old('review')).'','placeholder' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Close</button>
                                                        <button class="btn btn-success" type="submit">
                                                            <i class="fas fa-check mr-1"></i> Save Review
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- end mobile -->
                                <!-- desktop -->
                                <div class="d-none d-md-block d-lg-block mt-3">

                                    <a href="<?php echo e(route('course.show', $data->course->slug)); ?>"
                                        class="btn shadow btn-dark btn-md mb-2">
                                        <i class="fas fa-play mr-1"></i>
                                        Lanjutkan Belajar
                                    </a>
                                    <button type="button" class="btn btn-primary btn-md mb-2" data-toggle="modal"
                                        data-target="#modal-lg<?php echo e($data->course->id); ?>">
                                        <i class="fas fa-comments mr-1"></i> Review Course
                                    </button>
                                    
                                    <?php if($data->course->certificate_id != null): ?>
                                        <?php if($data->course->certificate_path != null): ?>
                                            <form action="<?php echo e(route('member.certificate.download', ['certificate' => $data->course->id])); ?>" method="GET">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('GET'); ?>
                                                <button type="submit" class="btn btn-primary btn-md mb-2">
                                                    <i class="fas fa-comments mr-1"></i> Lihat Sertifikat
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('member.certificate.generate', ['course' => $data->course->id])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn btn-primary btn-md mb-2">
                                                    <i class="fas fa-comments mr-1"></i> Cetak sertifikat
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    
                                    <div class="modal fade" id="modal-lg<?php echo e($data->course->id); ?>">
                                        <div class="modal-dialog modal-lg">
                                            <form action="<?php echo e(route('member.review', $data->course->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Review Course</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php if (isset($component)) { $__componentOriginalbf566fc26595b9cc6779e170beef8a5a = $component; } ?>
<?php $component = App\View\Components\Select::resolve(['name' => 'rating','title' => 'Rating'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                            <option value="1">1 </option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $component = $__componentOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php $component = App\View\Components\Textarea::resolve(['title' => 'Review','name' => 'review','value' => ''.e(old('review')).'','placeholder' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Close</button>
                                                        <button class="btn btn-success" type="submit">
                                                            <i class="fas fa-check mr-1"></i> Save Review
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="modal-default<?php echo e($data->course->id); ?>">
                                        <div class="modal-dialog">
                                            <form action="<?php echo e(route('member.review', $data->course->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Review Course</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="name">Role Name</label>
                                                            <input type="text" name="name" class="form-control"
                                                                id="name" placeholder="Enter role name"
                                                                value="">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Close</button>
                                                        <button class="btn btn-primary" type="submit">
                                                            <i class="fas fa-check mr-1"></i> Update role
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- end desktop -->
                                <hr>
                                <div class="mt-2">
                                    Licensed to :
                                    <p>
                                        <b><?php echo e($data->transaction->user->name); ?></b>
                                        <i>(<?php echo e($data->transaction->user->email); ?>)</i>
                                        — <?php echo e($data->transaction->created_at->format('d-m-Y H:i:s')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="row">
                            <div class="col-12 d-flex justify-content-center">
                                <img src="<?php echo e(asset('course.svg')); ?>" class="img-fluid" width="30%">
                            </div>
                            <div class="col-12 my-4">
                                <h5 class="text-center font-weight-bold text-md">
                                    Anda belum memiliki course !
                                </h5>
                                <p class="text-center text-secondary text-sm">
                                    Silahkan tambahkan playlist course anda, dan mulailah bangun diri anda sesuai dengan
                                    yang anda impikan.
                                </p>
                                <div class="d-flex justify-content-center">
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-dark btn-sm">
                                        Lihat Daftar Course
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-end"><?php echo e($courses->links()); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', ['title' => 'Course'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/member/course/mycourse.blade.php ENDPATH**/ ?>