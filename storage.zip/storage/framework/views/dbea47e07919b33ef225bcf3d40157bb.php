<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center">
        <div class="col-10">
            <form action="<?php echo e(route('admin.category.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalfd47a00662785e5fd1c21eb989b83081 = $component; } ?>
<?php $component = App\View\Components\CardForm::resolve(['title' => 'CREATE NEW CATEGORY','url' => ''.e(route('admin.category.index')).'','titleBtn' => 'Create Category'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CardForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php if (isset($component)) { $__componentOriginal786b6632e4e03cdf0a10e8880993f28a = $component; } ?>
<?php $component = App\View\Components\Input::resolve(['title' => 'Title','type' => 'text','name' => 'name','placeholder' => 'Enter category title','value' => old('name')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a)): ?>
<?php $component = $__componentOriginal786b6632e4e03cdf0a10e8880993f28a; ?>
<?php unset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal054404a577d6e9fb688559e9fc2a2812 = $component; } ?>
<?php $component = App\View\Components\UploadFile::resolve(['title' => 'Image','name' => 'image','value' => old('image')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('upload-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UploadFile::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal054404a577d6e9fb688559e9fc2a2812)): ?>
<?php $component = $__componentOriginal054404a577d6e9fb688559e9fc2a2812; ?>
<?php unset($__componentOriginal054404a577d6e9fb688559e9fc2a2812); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd47a00662785e5fd1c21eb989b83081)): ?>
<?php $component = $__componentOriginalfd47a00662785e5fd1c21eb989b83081; ?>
<?php unset($__componentOriginalfd47a00662785e5fd1c21eb989b83081); ?>
<?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', ['title' => 'Category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/admin/category/create.blade.php ENDPATH**/ ?>