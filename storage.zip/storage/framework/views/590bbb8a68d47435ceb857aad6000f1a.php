<?php $__env->startSection('content'); ?>
    <!-- hero section -->
    <?php if (isset($component)) { $__componentOriginal6260a6b47e639c5c13135ddb2c41049d = $component; } ?>
<?php $component = App\View\Components\Landing\HeroSection::resolve(['title' => 'Category','subtitle' => 'Kumpulan video tutorial dengan category '.e(str()->lower($category->name)).'','details' => 'Disini kita akan mempelajarinya semua dari awal, jangan terlalu lama berfikir! karena disini tidak hanya mengajarkan tentang fundamental tetapi dengan studi kasus didalamnya.','cardtitle' => 'Course'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\HeroSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($courses)]); ?>
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-category-2 h-10 w-10 md:w-20 md:h-20"
            width="24" height="24" viewBox="0 0 24 24" stroke-width="1.25" stroke="white" fill="none"
            stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <path d="M14 4h6v6h-6z"></path>
            <path d="M4 14h6v6h-6z"></path>
            <circle cx="17" cy="17" r="3"></circle>
            <circle cx="7" cy="7" r="3"></circle>
        </svg>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6260a6b47e639c5c13135ddb2c41049d)): ?>
<?php $component = $__componentOriginal6260a6b47e639c5c13135ddb2c41049d; ?>
<?php unset($__componentOriginal6260a6b47e639c5c13135ddb2c41049d); ?>
<?php endif; ?>
    <!-- search section -->
    <?php if (isset($component)) { $__componentOriginalec34e7763d23a96ad0a81b02e840c3b3 = $component; } ?>
<?php $component = App\View\Components\Landing\SearchSection::resolve(['url' => route('category', $category->slug)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.search-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\SearchSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec34e7763d23a96ad0a81b02e840c3b3)): ?>
<?php $component = $__componentOriginalec34e7763d23a96ad0a81b02e840c3b3; ?>
<?php unset($__componentOriginalec34e7763d23a96ad0a81b02e840c3b3); ?>
<?php endif; ?>
    <!-- course section -->
    <div class="w-full bg-gray-100 p-3 border border-line border-gray-100">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 container mx-auto my-5 items-start">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal8d5a4296fdb14d42fb41edd80523d306 = $component; } ?>
<?php $component = App\View\Components\Landing\CourseItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing.course-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Landing\CourseItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['course' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d5a4296fdb14d42fb41edd80523d306)): ?>
<?php $component = $__componentOriginal8d5a4296fdb14d42fb41edd80523d306; ?>
<?php unset($__componentOriginal8d5a4296fdb14d42fb41edd80523d306); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', ['title' => 'Course'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\62831\course\resources\views/landing/category/show.blade.php ENDPATH**/ ?>