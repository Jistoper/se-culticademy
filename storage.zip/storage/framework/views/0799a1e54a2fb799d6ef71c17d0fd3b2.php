<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $showcases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showcase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-12">
                <div class="card card-dark card-outline shadow-none">
                    <div class="ribbon-wrapper ribbon-lg">
                        <div class="ribbon bg-primary">
                            <?php echo e($showcase->created_at->diffForHumans()); ?>

                        </div>
                    </div>
                    <div class="card-body box-profile">
                        <div class="text-center">
                            <img class="img-fluid" src="<?php echo e($showcase->cover); ?>" alt="cover">
                        </div>
                        <h3 class="profile-username text-center"><?php echo e($showcase->name); ?></h3>
                        <h3 class="text-center font-weight-bold">
                            <?php echo e($showcase->title); ?>

                        </h3>
                        <p class="text-center text-secondary"><?php echo e($showcase->description); ?></p>
                        <hr>
                        <div>
                            <div>
                                <i class="fas fa-circle text-xs"></i>
                                Course
                            </div>
                            <p><?php echo e($showcase->course->name); ?></p>
                        </div>
                        <hr />
                        <div>
                            <div>
                                <i class="fas fa-circle text-xs"></i>
                                User
                            </div>
                            <p><?php echo e($showcase->user->name); ?> - (<?php echo e($showcase->user->email); ?>)</p>
                        </div>
                        <hr />
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', ['title' => 'Showcase'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\SE\course\resources\views/admin/showcase/index.blade.php ENDPATH**/ ?>