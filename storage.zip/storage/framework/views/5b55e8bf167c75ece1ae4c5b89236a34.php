<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['carts', 'total']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['carts', 'total']); ?>
<?php foreach (array_filter((['carts', 'total']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="border border-gray-300 rounded-lg overflow-hidden">
    <div class="bg-white border-b px-4 py-3 text-gray-700 font-medium flex items-center gap-1">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-basket w-5 h-5" width="24"
            height="24" viewBox="0 0 24 24" stroke-width="1.25" stroke="currentColor" fill="none"
            stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <polyline points="7 10 12 4 17 10"></polyline>
            <path d="M21 10l-2 8a2 2.5 0 0 1 -2 2h-10a2 2.5 0 0 1 -2 -2l-2 -8z"></path>
            <circle cx="12" cy="15" r="2"></circle>
        </svg>
        Keranjang Saya
    </div>
    <div class="overflow-x-auto relative">
        <table class="w-full text-sm text-left text-gray-500 divide-y divide-gray-200">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                    <th scope="col" class="px-4 py-3 w-0"></th>
                    <th scope="col" class="px-4 py-3">Nama Barang</th>
                    <th scope="col" class="px-4 py-3 text-right">Jumlah</th>
                    <th scope="col" class="px-4 py-3 w-0">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="py-3 px-4 whitespace-nowrap">
                            <?php echo e($i + 1); ?>

                        </td>
                        <td class="py-3 px-4 whitespace-nowrap">
                            <?php echo e($cart->course->name); ?></td>
                        <td class="py-3 px-4 whitespace-nowrap text-right font-mono">
                            <sup>Rp</sup> <?php echo e(moneyFormat($cart->price)); ?>

                        </td>
                        <td class="py-3 px-4 whitespace-nowrap text-right text-red-500">
                            <a href="#" onclick="deleteData(<?php echo e($cart->id); ?>)">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                    class="icon icon-tabler icon-tabler-eraser w-5 h-5" width="24" height="24"
                                    viewBox="0 0 24 24" stroke-width="1.25" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path
                                        d="M19 20h-10.5l-4.21 -4.3a1 1 0 0 1 0 -1.41l10 -10a1 1 0 0 1 1.41 0l5 5a1 1 0 0 1 0 1.41l-9.2 9.3">
                                    </path>
                                    <path d="M18 13.3l-6.3 -6.3"></path>
                                </svg>
                            </a>
                            <form id="delete-form-<?php echo e($cart->id); ?>" action="<?php echo e(route('cart.destroy', $cart->id)); ?>"
                                method="POST" style="display:none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td class="py-3 px-4 whitespace-nowrap" colspan="4">
                            <div class="flex items-center justify-center h-96">
                                <div class="text-center flex flex-col items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-basket"
                                        width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                        stroke="currentColor" fill="none" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                        <polyline points="7 10 12 4 17 10"></polyline>
                                        <path d="M21 10l-2 8a2 2.5 0 0 1 -2 2h-10a2 2.5 0 0 1 -2 -2l-2 -8z">
                                        </path>
                                        <circle cx="12" cy="15" r="2"></circle>
                                    </svg>
                                    <div class="mt-5">
                                        Keranjang Anda Kosong
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
                <tr classname="bg-blue-50 text-blue-900 font-semibold">
                    <td class="py-3 px-4 whitespace-nowrap"></td>
                    <td class="py-3 px-4 whitespace-nowrap">Total</td>
                    <td class="py-3 px-4 whitespace-nowrap text-right text-green-500 font-mono">
                        <sup>Rp</sup> <?php echo e(moneyFormat($total)); ?>

                    </td>
                    <td class="py-3 px-4 whitespace-nowrap"></td>
                </tr>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\Users\62831\course\resources\views/components/landing/cart-table.blade.php ENDPATH**/ ?>