<form action="<?php echo e($url); ?>" method="GET">
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="<?php echo e($placeholder); ?>" value="<?php echo e(request()->search); ?>"
            name="search">
        <span class="input-group-append">
            <button type="button" class="btn btn-dark">
                <i class="fas fa-search"></i>
            </button>
        </span>
    </div>
</form><?php /**PATH C:\Users\62831\course\resources\views/components/input-search.blade.php ENDPATH**/ ?>